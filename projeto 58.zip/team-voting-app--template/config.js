import firebase from 'firebase';

  var firebaseConfig = {
    //cole seu SDK aqui
    const firebaseConfig = {
  apiKey: "AIzaSyAlZ7poDQvUsuPWx8RIIbdfSjBCbovCfqo",
  authDomain: "projeto-58-1423d.firebaseapp.com",
  databaseURL: "https://projeto-58-1423d-default-rtdb.firebaseio.com",
  projectId: "projeto-58-1423d",
  storageBucket: "projeto-58-1423d.appspot.com",
  messagingSenderId: "346856946895",
  appId: "1:346856946895:web:54769ed9b7200da8a50bba"
};
    
  };

  // Inicialize o Firebase
  firebase.initializeApp(firebaseConfig);
  
  export default firebase.database();